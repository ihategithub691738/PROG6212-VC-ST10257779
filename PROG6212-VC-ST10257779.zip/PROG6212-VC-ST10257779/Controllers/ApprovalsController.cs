using Microsoft.AspNetCore.Mvc;
using PROG6212_VC_ST10257779.Data;
using PROG6212_VC_ST10257779.Models;
using System.Linq;

namespace PROG6212_VC_ST10257779.Controllers
{
    public class ApprovalsController : Controller
    {
        public IActionResult Index()
        {
            var view = from a in FakeDb.Approvals
                       join c in FakeDb.Claims on a.ClaimId equals c.Id
                       join l in FakeDb.Lecturers on c.LecturerId equals l.Id
                       orderby c.Id
                       select new { a.Id, a.ClaimId, Lecturer = l.FullName, a.Role, a.Status, c.Amount };
            return View(view.ToList());
        }
    }
}

/*
 * Code assistance: OpenAI ChatGPT
 * Code assistance: STACKOVERFLOW
 * Date: 2025-09-14
 */
        [HttpPost]
        public IActionResult Approve(int id)
        {
            var approval = FakeDb.Approvals.FirstOrDefault(a => a.Id == id);
            if (approval == null) return NotFound();

            approval.Status = ApprovalStatus.Approved;

            // If all approvals are approved, mark claim Approved
            var claim = FakeDb.Claims.First(c => c.Id == approval.ClaimId);
            if (FakeDb.Approvals.Where(a => a.ClaimId == claim.Id).All(a => a.Status == ApprovalStatus.Approved))
                claim.Status = ClaimStatus.Approved;
            else
                claim.Status = ClaimStatus.Verified;

            TempData["Message"] = $"Approval {id} set to APPROVED";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult Reject(int id)
        {
            var approval = FakeDb.Approvals.FirstOrDefault(a => a.Id == id);
            if (approval == null) return NotFound();

            approval.Status = ApprovalStatus.Rejected;
            var claim = FakeDb.Claims.First(c => c.Id == approval.ClaimId);
            claim.Status = ClaimStatus.Rejected;

            TempData["Message"] = $"Approval {id} set to REJECTED";
            return RedirectToAction(nameof(Index));
        }
    }
}
