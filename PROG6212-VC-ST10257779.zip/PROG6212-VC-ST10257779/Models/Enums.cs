namespace PROG6212_VC_ST10257779.Models
{
    public enum ClaimStatus { Draft, Submitted, Verified, Approved, Rejected, Paid }
    public enum ApproverRole { ProgrammeCoordinator, AcademicManager }
    public enum ApprovalStatus { Pending, Approved, Rejected }
}
/*
 * Code assistance: OpenAI ChatGPT
 * Code assistance: STACKOVERFLOW
 * Date: 2025-09-14
 */

