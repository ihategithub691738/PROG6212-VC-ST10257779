
using System.ComponentModel.DataAnnotations;

namespace PROG6212_VC_ST10257779.ViewModels
{
    public class ClaimForm
    {
        [Required]
        public int LecturerId { get; set; }

        [Range(2020, 2100)]
        public int Year { get; set; }

        [Range(1, 12)]
        public int Month { get; set; }

        [Range(0.5, 300)]
        public decimal HoursWorked { get; set; }

        [Range(50, 2000)]
        public decimal HourlyRate { get; set; }
    }
}
